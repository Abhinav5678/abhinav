/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define MAX_SIZE 100
//function declation 

int maximum  (int arr[], int start, int len);
int
main ()
{
  int arr[MAX_SIZE],max;
  int N, i;

  printf ("Enter size: ");
  scanf ("%d", &N);
  printf ("Enter elements : ");
  for (i = 0; i < N; i++)
    {
      scanf ("%d", &arr[i]);
    }
  max = maximum (arr, 0, N);          //function calling
  printf ("maximum of array elements: %d",max );

  return 0;
}

//defination

int maximum  (int arr[], int start, int len)
{
    int max;
  if (start <= len)
  {
      if (arr[start]>arr[start+1])
      return arr[start];
      else 
      return arr[start +1];
      
  }
  max = maximum(arr,start+1,len);

    
    
}
  
  
  
  
  
  

