/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  char gender;
  printf ("dear user please enter your gender:-");
  scanf ("%c", &gender);
  if (gender == 'm')
    {
      printf ("dear user you are a male");
    }
  else if (gender == 'f')
    {
      printf ("dear user you are a female");
    }
  else
    {
      printf ("dear user you are a transgender");
    }
  return 0;
}
