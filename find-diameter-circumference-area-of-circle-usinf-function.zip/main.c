/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int diameter (int r);
int circumference (int r);
int area (int r);

int
main ()
{
  int r, circumference, area, diameter;
  printf ("enter the  radius-:");
  scanf ("%d", &r);

  diameter = dia (int r);
  circumference = circum (int r);
  area = ar (int r);
  printf ("diameter of  given radius is  -:%d", diameter);
  printf ("circumference of  given radius is  -:%d", circumference);
  printf (" area of  given radius is  -:%d", area);
  return 0;
}

int
dia (int r)
{
  int diamtr;
  diamtr = 2 * r;
  return diamtr;
}

float
circum (float r)
{
  float circum;
  circum = 2 * 3.14 * r;
  return circum;
}

float
ar (float r)
{
  float ar;
  ar = 3.14 * r * r;
  return ar;
}
