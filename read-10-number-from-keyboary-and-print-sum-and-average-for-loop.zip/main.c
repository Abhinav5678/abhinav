/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  int i, n, sum = 0;
  float average;
  printf ("input the 10 number\n");
  for (i = 1; i <= 10; ++i)
    {
      printf ("number%d-", i);
      scanf ("%d", &n);
      sum = n;
    }
  average = sum / 10.0;
  printf ("the sum of 10 number is-%d\n the average is-%f\n", sum, average);
}
